package org.cipango.ims.hss;

public class HssException extends Exception
{
	public HssException(String message)
	{
		super(message);
	}
}
