#! /bin/sh
./HSS/bin/hss.sh stop &
./P-CSCF/bin/pcscf.sh stop &
./S-CSCF/bin/scscf.sh stop &
./I-CSCF/bin/icscf.sh stop

